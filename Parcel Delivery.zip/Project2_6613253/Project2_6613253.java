//Thammanat Lerdwijitjarud 6613253
//Pornnubpun Rujicheep 6613257
//Pimlapas   Narasawad 6613264

package Project2_6613253;

import java.util.*;
import java.util.concurrent.*;
import java.io.*;

class Fleet {
    private String type;
    private int max_car, max_load;
    public int remainfleet, remain;

    public Fleet(String ty, int car, int load) {
        type = ty;
        max_car = car;
        max_load = load;
        remainfleet = max_car;
    }
    
    public String getType() {
        return type;
    }

    public int getMaxLoad() {
        return max_load;
    }

    public int getRemainFleet() {
        return remainfleet;
    }
    
    public synchronized void resetFleet() {
        remainfleet = max_car;
    }
    
    public synchronized int[] calculateFleet(int parcel, DeliveryShop shop) {
        int fleetUse = Math.min(parcel/max_load, remainfleet);
        shop.deliveredParcel = fleetUse * max_load;  // Parcels delivered by used fleets
        int remainingParcels = parcel - shop.deliveredParcel;
        remainfleet -= fleetUse;
        // If remaining parcels are at least half the max load, use one more fleet if available
        if (remainingParcels >= Math.ceil(max_load / 2.0) && remainfleet > 0) {
            shop.deliveredParcel += remainingParcels;
            fleetUse += 1;
            remainfleet -= 1;
        }
        int[] ans = new int[2];
        ans[0] = fleetUse;
        ans[1] = remainfleet;
        return ans;
    }
}

class DeliveryShop implements Comparable<DeliveryShop>{
    private String name;
    Fleet fleet;
    private int parcelToday = 0, totalParcel = 0, total_delivered=0,  totalReceived=0;
    private double successRate;
    protected int deliveredParcel, remainParcel, fleetUsed;

    public DeliveryShop(String n, Fleet f) {
        name = n;
        fleet = f;
    }

    public String getName() {
        return name;
    }

    public synchronized void setParcel(int parcel) {
        parcelToday = parcel;
        totalReceived += parcel;
        totalParcel += parcelToday;
    }

    public synchronized void printDetails() {
        System.out.printf("%15s >>     parcels to deliver = %4d\n", Thread.currentThread().getName(), totalParcel);
        parcelToday = 0;
    }
    
    public synchronized void printAllocate() {
        int[] ans = fleet.calculateFleet(totalParcel, this);
        //ans[0] = fleetUse, ans[1] = remainfleet
        remainParcel = totalParcel - deliveredParcel;
        total_delivered += deliveredParcel;
        System.out.printf("%15s >> deliver = %4d, by %2d %6s, remaining parcels = %3d, remaining %-6s = %2d\n",
                Thread.currentThread().getName(), deliveredParcel, ans[0], fleet.getType(), remainParcel, fleet.getType(), ans[1]);

        totalParcel = remainParcel;
    }
    
    public double successRate(){
        if(totalReceived==0){
            successRate=0.0;
        }
        successRate = (double)total_delivered /totalReceived;
        return successRate;
    }
    
    public void printSummary(){
        System.out.printf("%15s >> %-17s received = %4d, delivered = %4d, success rate = %.2f\n", Thread.currentThread().getName(), name, totalReceived, total_delivered, successRate);
    }
    
    @Override
    public int compareTo(DeliveryShop other){
        this.successRate = this.successRate();
        other.successRate = other.successRate();
        if (this.successRate > other.successRate)       return -1;	
            else if (this.successRate < other.successRate)  return 1;	
            else{
                return (this.name).compareTo(other.name);
            }
    }
}

class DeliveryThread extends Thread {
    DeliveryShop shop;
    Fleet fleet;
    CyclicBarrier deliveryBarrier;
    CyclicBarrier betweenBarrier;
    CyclicBarrier sellerBarrier;
    private int totalDays;

    public DeliveryThread(DeliveryShop sh, int day, CyclicBarrier sellerBar, CyclicBarrier deliveryBar, CyclicBarrier betweenBar) {
        shop = sh;
        fleet = sh.fleet;
        totalDays = day;
        deliveryBarrier = deliveryBar;
        betweenBarrier = betweenBar;
        sellerBarrier = sellerBar;
    }

    @Override
    public void run() {
        for(int i=0; i<totalDays; i++){
            try{
                sellerBarrier.await();
                shop.printDetails();
                betweenBarrier.await();
                shop.printAllocate();
                deliveryBarrier.await();
            } catch (InterruptedException | BrokenBarrierException e) {
                e.printStackTrace();
            }
        }
    }
}

class SellerThread extends Thread {
    private String name;
    private int max_drop, totalDays;
    private Random random = new Random();
    private CyclicBarrier sellerBarrier, mainBarrier;
    ArrayList<DeliveryShop> shop;

    public SellerThread(String n, int max, int days, CyclicBarrier mainBar, CyclicBarrier sellerBar, ArrayList<DeliveryShop> sh) {
        name = n;
        max_drop = max;
        totalDays = days;
        sellerBarrier = sellerBar;
        mainBarrier = mainBar;
        shop = sh;
    }

    public void randomShop(int parcels) {
        int randomIndex = random.nextInt(shop.size());
        DeliveryShop chosenShop = shop.get(randomIndex);
        chosenShop.setParcel(parcels);
        System.out.printf("%15s >> drop %4d parcels at %-17s shop\n", name, parcels, chosenShop.getName());
    }
    
    @Override
    public void run() {
        for(int i=0; i<totalDays; i++){
            try{
                mainBarrier.await();
                int parcelToDeliver = random.nextInt(max_drop) + 1;
                randomShop(parcelToDeliver);
                sellerBarrier.await();
            } catch (InterruptedException | BrokenBarrierException e) {
                e.printStackTrace();
            }
        }
    }
}

public class Project2_6613253{
    int totalDays;
    int bikeNum, bikeMaxLoad;
    int truckNum, truckMaxLoad;
    int sellerNum, maxParcelDrop;
    int deliveryByBike, deliveryByTruck;

    public static void main(String[] args) {
        Project2_6613253 mainApp = new Project2_6613253();
        String path = "src/main/java/Project2_6613253/";
        String filename = "config.txt";
        mainApp.readFile(path, filename);
        
        ArrayList<Fleet> allFleet = new ArrayList<>();
        Fleet bikeFleet = new Fleet("bikes", mainApp.bikeNum, mainApp.bikeMaxLoad);
        allFleet.add(bikeFleet);
        Fleet truckFleet = new Fleet("trucks", mainApp.truckNum, mainApp.truckMaxLoad);
        allFleet.add(truckFleet);
        
        // Create barrier
        CyclicBarrier dayBarrier = new CyclicBarrier(1);
        CyclicBarrier mainBarrier = new CyclicBarrier(mainApp.sellerNum + 1);
        CyclicBarrier sellerBarrier = new CyclicBarrier(mainApp.deliveryByBike + mainApp.deliveryByTruck + mainApp.sellerNum);
        CyclicBarrier deliveryBarrier = new CyclicBarrier(mainApp.deliveryByBike + mainApp.deliveryByTruck + 1);
        CyclicBarrier betweenDeliveryBarrier = new CyclicBarrier(mainApp.deliveryByBike + mainApp.deliveryByTruck);

        ArrayList<DeliveryShop> deliveryShop = new ArrayList<>();
        for (int i = 0; i < mainApp.deliveryByBike; i++) {
            deliveryShop.add(new DeliveryShop("BikeDelivery_" + i, bikeFleet));
        }
        for (int i = 0; i < mainApp.deliveryByTruck; i++) {
            deliveryShop.add(new DeliveryShop("TruckDelivery_" + i, truckFleet));
        }

        ArrayList<SellerThread> allSellers = new ArrayList<>();
        for (int i = 0; i < mainApp.sellerNum; i++) {
            allSellers.add(new SellerThread("Seller_" + i, mainApp.maxParcelDrop, mainApp.totalDays, mainBarrier, sellerBarrier, deliveryShop));
        }

        ArrayList<DeliveryThread> deliveryThreads = new ArrayList<>();
        for (DeliveryShop shop : deliveryShop) {
            DeliveryThread deliver_t = new DeliveryThread(shop, mainApp.totalDays, sellerBarrier, deliveryBarrier, betweenDeliveryBarrier);
            deliver_t.setName(shop.getName());
            deliveryThreads.add(deliver_t);
        }

        for (SellerThread seller : allSellers) {
            seller.start();
        }

        for (DeliveryThread delivery : deliveryThreads) {
            delivery.start();
        }

        for (int day = 0; day < mainApp.totalDays; day++) {
            System.out.printf("%15s >> \n", Thread.currentThread().getName());
            System.out.printf("%15s >> %s\n", Thread.currentThread().getName(), "=".repeat(52));
            System.out.printf("%15s >> Day %d\n", Thread.currentThread().getName(), day + 1);
            try {
                for(Fleet f : allFleet){
                    f.resetFleet();
                }
                dayBarrier.await();
                //seller
                mainBarrier.await();
                //delivery
                deliveryBarrier.await();
                
            } catch (InterruptedException | BrokenBarrierException e) {
                e.printStackTrace();
            }
        }
        try{
            for (SellerThread seller : allSellers) {
                seller.join();
            }
            for (DeliveryThread delivery : deliveryThreads) {
                delivery.join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        //print summary
        System.out.printf("%15s >> \n", Thread.currentThread().getName());
        System.out.printf("%15s >> %s\n", Thread.currentThread().getName(), "=".repeat(52));
        System.out.printf("%15s >> Summary\n", Thread.currentThread().getName());
        mainApp.printSummary(deliveryShop);
    }
    
    public void printSummary(ArrayList<DeliveryShop> deliveryShop) {
        // Sort by success rate, then by name if equal
        Collections.sort(deliveryShop);
        for (DeliveryShop shop : deliveryShop) {
            shop.printSummary();
        }
    }

  public void readFile(String path, String filename) {
        Scanner input = new Scanner(System.in);
        boolean opensuccess = false;
        while (!opensuccess) {
            try {
                File inFile = new File(path + filename);
                Scanner fileScan = new Scanner(inFile);
                opensuccess = true;
                
                while (fileScan.hasNext()) {
                    String line = fileScan.nextLine();
                    String[] cols = line.split(",");
                    switch (cols[0]) {
                        case "days":
                            System.out.printf("%15s >> %s Parameters %s\n", Thread.currentThread().getName(), "=".repeat(20), "=".repeat(20));
                            totalDays = Integer.parseInt(cols[1].trim());
                            System.out.printf("%15s >> days of simulation = %d\n", Thread.currentThread().getName(), totalDays);
                            break;
                        case "bike_num_maxload":
                            bikeNum = Integer.parseInt(cols[1].trim());
                            bikeMaxLoad = Integer.parseInt(cols[2].trim());
                            System.out.printf("%15s >> Bike  Fleet, total bikes   =%4d, max load =%4d parcels, min load =%4d parcels\n", Thread.currentThread().getName(), bikeNum, bikeMaxLoad, (int) Math.ceil(bikeMaxLoad / 2));
                            break;
                        case "truck_num_maxload":
                            truckNum = Integer.parseInt(cols[1].trim());
                            truckMaxLoad = Integer.parseInt(cols[2].trim());
                            System.out.printf("%15s >> Truck Fleet, total trucks  =%4d, max load =%4d parcels, min load =%4d parcels\n", Thread.currentThread().getName(), truckNum, truckMaxLoad, (int) Math.ceil(truckMaxLoad / 2));
                            break;
                        case "seller_num_maxdrop":
                            ArrayList<String> sellerName = new ArrayList<>();
                            sellerNum = Integer.parseInt(cols[1].trim());
                            maxParcelDrop = Integer.parseInt(cols[2].trim());
                            for (int i = 0; i < sellerNum; i++) {
                                sellerName.add("Seller_" + i);
                            }
                            System.out.printf("%15s >> %-17s = %s\n", Thread.currentThread().getName(), "SellerThreads", sellerName);
                            System.out.printf("%15s >> max parcels drop  = %4d\n", Thread.currentThread().getName(), maxParcelDrop);
                            break;
                        case "delivery_bybike_bytruck":
                            ArrayList<String> deliveryName = new ArrayList<>();
                            deliveryByBike = Integer.parseInt(cols[1].trim());
                            deliveryByTruck = Integer.parseInt(cols[2].trim());
                            for (int i = 0; i < deliveryByBike; i++) {
                                deliveryName.add("BikeDelivery_" + i);
                            }
                            for (int i = 0; i < deliveryByTruck; i++) {
                                deliveryName.add("TruckDelivery_" + i);
                            }
                            System.out.printf("%15s >> %-17s = %s\n", Thread.currentThread().getName(), "deliveryName", deliveryName);
                            break;
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("\n" + e);
                System.out.println("New file name =");
                filename = input.nextLine();
            }
        }
    }
}