source_code_pipeline เป็นไฟล์ .py ที่รวม flow การทำงานทั้งหมด
streamlit_app เป็นไฟล์ .py ที่ทำ web application
best.pt คือ model ที่ได้มาจากการ train dataset เอง
yolo11n.pt คือ model ที่สำเร็จรูปของ yolo
bytetrack.yaml ใช้สำหรับการทำ tracking
.streamlit เป็น folder ที่เป็น configuration ของ streamlit