#import nessesary library
import os
from pathlib import Path
import json
import cv2
import numpy as np
import faiss
import torch
import clip  # from openai/CLIP
from PIL import Image
from ultralytics import YOLO
import warnings
from supervision import ByteTrack

device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/32", device=device)

# yolo_model =YOLO("best.pt")
# imgsz=640
# conf=0.25
# every_n_frames=30

#---------- create log ------------------

def create_log(video_path, video_name, yolo_model, imgsz, conf, every_n_frames):

    # get frame
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open {video_path}")
    video_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0

    # iterate throgh each frame
    logs = []
    frame_idx = -1
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_idx += 1
        if frame_idx % every_n_frames != 0:
            continue # skip some frame
        # timestamp = frame_idx / video_fps

        # do detection (use model.predict on this frame)
        results = yolo_model.predict(frame, imgsz=imgsz, conf=conf)
        
        if len(results) == 0: # detect nothing
            continue
        det = results[0]
        if getattr(det, "boxes", None) is None or len(det.boxes) == 0:
            continue # get attr

        for box in det.boxes:
            # bbox extraction safe path
            try:
                xyxy = box.xyxy.cpu().numpy().flatten()
            except Exception:
                xyxy = np.array(box.xyxy).flatten()
            x1, y1, x2, y2 = map(int, xyxy) # 4 points position

            # clamp: keep the predition box inside the image
            h, w = frame.shape[:2] # Extract the image height and width.
            x1c, y1c = max(0, x1), max(0, y1)
            x2c, y2c = min(w-1, x2), min(h-1, y2)
            if x2c <= x1c or y2c <= y1c:
                continue

            # class
            try:
                class_id = int(getattr(box, "cls", 0))
                class_name = yolo_model.names[class_id]
            except Exception:
                class_id = 0
                class_name = str(class_id)

            logs.append({
                "frame_idx": frame_idx,
                "class_name": class_name,
                "bbox": [x1c, y1c, x2c, y2c],
            })

    cap.release()

    # didn't use mount drive, save directly
    with open(video_name+".json", "w") as f:
        json.dump(logs, f, indent=4)

    print("[process_video_with_clip] done")
    print("frame_idx = ", frame_idx)

#---------- detect object class ------------------

def detect_object_class(image_path):
    model = YOLO("yolo11n.pt")
    results = model.predict(image_path, classes=[0, 24, 63, 56, 73])   
    # print(results)
    class_names = results[0].names
    detected = [class_names[int(c)] for c in results[0].boxes.cls]
    if len(detected) != 0:
        if detected == ['book']:
            detected = ['notebook']
        return detected, int(results[0].boxes.cls[0].item())
    else:
        return [], -1


#---------- embedding vector ------------------

def get_embedding(input_image):

    if isinstance(input_image, str):
        img = Image.open(input_image).convert("RGB")
    elif isinstance(input_image, np.ndarray):
        img = Image.fromarray(cv2.cvtColor(input_image, cv2.COLOR_BGR2RGB))
    else:
        img = input_image.convert("RGB")

    # Preprocess using CLIP's official transform -> [batch, channels, H, W]
    img_preprocessed = preprocess(img).unsqueeze(0).to(device)

    with torch.no_grad():
        embedding = model.encode_image(img_preprocessed) # 512-D embedding vector
        embedding = embedding / embedding.norm(dim=-1, keepdim=True)  # Normalize 1 vector length

    return embedding.cpu().numpy().flatten() # Returns Tensor -> numpy array

def get_closest_embedding(crop, query_image): # get images to compare
    dim = 512
    index = faiss.IndexFlatL2(512)   # simple exact index
    embedded = []

    for i in crop:
        embedded.append(get_embedding(i).astype("float32"))
    embedded_matrix = np.vstack(embedded)


    index = faiss.IndexFlatL2(dim)  # L2 distance (can switch to cosine)
    index.add(embedded_matrix)

    query_emb = get_embedding(query_image).astype("float32").reshape(1, -1)

    # k = min(len(crop), 5)
    k = 1

    distances, indices = index.search(query_emb, k)
    # indices = which items in your list are the closest
    # distances = similarity distances

    return indices

#---------- find last seen frame ------------------

def find_last_seen_frame(video_path, finding, video_name):
    # get last frame item exist (by object type)
    with open(video_name + ".json", "r") as f:
        logs = json.load(f)
    items = []
    flag = 0
    found_frame = 0
    for i in logs[::-1]:
        # the next frame_idx after we found the object is not the same -> no duplicate item -> found the last frame item exist
        if flag == 1 and i["frame_idx"] != found_frame:
            break
        if i["class_name"] == finding:
            items.append(i)
            found_frame = i["frame_idx"]
            flag = 1
            print(i)

    # check if there are more than one target item
    if (len(items)==0):
        print("Not found")
        return [], -1
    else:
        if (len(items) == 1):
            print("Found from frame = ", items[0]["frame_idx"])
        else:
            # compare embedding
            print("Found multiple, from frame = ", items[0]["frame_idx"])
        return items, items[0]["frame_idx"]
    

def get_all_crop_image(video_path, items):
    # in case there are more than one target item
    crop = []
    # crop candidate
    video = cv2.VideoCapture(video_path)
    for i in items:
        video.set(cv2.CAP_PROP_POS_FRAMES, i["frame_idx"])
        success, target_frame = video.read()
        x1, y1, x2, y2 = i["bbox"]
        crop.append(target_frame[y1:y2, x1:x2])

    return crop

#-------------- extract clip ----------------

def extract_clip(video_path, out_path, start_frame, duration):

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError("Cannot open video")
    fps = cap.get(cv2.CAP_PROP_FPS)
    # print(fps)
    start_f = int(max(0, start_frame - 5*fps)) #get frame
    end_f = int(min(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), int(start_frame + duration*fps)))

    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(out_path, fourcc, fps, (w, h))
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_f)

    for f in range(start_f, end_f):
        ret, frame = cap.read()
        if not ret:
            break
        out.write(frame)

    cap.release()
    out.release()

    print("done")
    print("Time: " + str(start_f/fps))
    print("Frame : " + str(start_frame))

#---------------- track object --------------------

def track_object(video_path, target_class, detected_cls, yolo_model):

    # Open video
    output_path = detected_cls + "_track_output.mp4"
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("Error opening video:", video_path)
        return

    # Video properties
    fps = cap.get(cv2.CAP_PROP_FPS)
    width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # Output writer
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    frame_id = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_id += 1

        # Run YOLO + ByteTrack (tracker="bytetrack.yaml")
        results = yolo_model.track(
            frame,
            tracker="bytetrack.yaml",
            conf = 0.5,
            persist=True,        # keep track IDs
            classes=[target_class]  # filter detection by class
        )

        # Expected shape: results[0].boxes
        if results[0].boxes is not None:
            for box in results[0].boxes:

                # Bounding box
                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()

                # Confidence
                conf = float(box.conf[0])

                # Detected class
                cls = int(box.cls[0])

                # Track ID from ByteTrack
                track_id = (
                    int(box.id[0]) if box.id is not None else -1
                )

                # Draw box
                cv2.rectangle(frame,
                              (int(x1), int(y1)),
                              (int(x2), int(y2)),
                              (0, 255, 0),
                              2)

                # Label
                label = f"ID:{track_id} Class:{cls} Conf:{conf:.2f}"
                cv2.putText(frame, label,
                            (int(x1), int(y1) - 5),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6, (0,255,0), 2)

        out.write(frame)

    cap.release()
    out.release()
    print(f"Saved tracked video to {output_path}")
    return output_path


# ------------------- create pipeline -------------------


def select_device():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, preprocess = clip.load("ViT-B/32", device=device)

import os
import tempfile

def pipeline(input_image, video_path_in, video_name):
    video_path = video_path_in
    yolo_model = YOLO("best.pt")
    imgsz=640
    conf=0.25
    every_n_frames=30

    create_log(video_path, video_name, yolo_model, imgsz, conf, every_n_frames)
    select_device()

    # detect query object
    detected_cls, query_class_index = detect_object_class(input_image)
    if detected_cls == [] and query_class_index == -1:
        return None
    query_class_index = [k for k, v in yolo_model.names.items() if v == detected_cls[0]][0]

    # check
    finding = detected_cls[0]
    print("finding = ", finding)
    print(query_class_index)

    # read_logs(video_name)
    items, frame_idx = find_last_seen_frame(video_path, finding, video_name)
    # if object not found in video, items = [], frame_idx = -1 -> shouldn't continue (break)
    # Notify user that the input image object can not detected in video _> (Not found or found but can not detect)
    if items != [] and frame_idx != -1:
        crop = get_all_crop_image(video_path, items)

        # check from embedding
        closest_item = get_closest_embedding(crop, input_image)
        closest_item_index = closest_item[0][0]
        print("Closest item = ", closest_item[0])

        #extract a part of cilp
        extract_clip(video_path, "clip_with_box.mp4", items[closest_item_index]["frame_idx"], 20)
        
        #use for define ouput video name
        video_name = video_path_in.split(".mp4")[0]
        print(video_path)
        output_video = track_object("clip_with_box.mp4", query_class_index, finding, yolo_model)
        print("final clip done")
        return output_video
    else:
        print("Not Found target object in video")
        return None

# yolo_model = YOLO("best.pt")
# print(yolo_model.names)