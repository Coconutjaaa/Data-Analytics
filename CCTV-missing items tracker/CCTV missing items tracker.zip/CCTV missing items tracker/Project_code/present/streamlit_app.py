
import streamlit as st 
import tempfile 
import os 
import time
from PIL import Image 
 
from source_code_pipeline import pipeline, detect_object_class
 
st.title("CCTV-Based Missing Item Tracker") 
 
uploaded_image = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg"]) 
uploaded_video = st.file_uploader("Upload a video", type=["mp4", "avi", "mov", "mkv"]) 
 
if uploaded_image is not None and uploaded_video is not None: 
    # Save uploaded image to a temp file 
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp_img: 
        tmp_img.write(uploaded_image.read()) 
        tmp_img_path = tmp_img.name 
 
    # Save uploaded video to a temp file 
    original_video_name = uploaded_video.name 
    st.text(original_video_name) 
    real_video_name = original_video_name.split(".")[0] #day19_short 
 
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp_vid: 
        tmp_vid.write(uploaded_video.read()) 
        tmp_vid_path = tmp_vid.name 
    
    # show input data
    st.image(Image.open(tmp_img_path), caption="Uploaded Image", width=400)
    
    # Show original video
    st.subheader("Original Video")
    st.video(tmp_vid_path)

    # pipeline_flag = False
    found_in_video = True
    pipeline_flag = False
    #show predicted object first
    if st.button("Predict Object"):
        detected_cls, query_class_index = detect_object_class(tmp_img_path)
        if len(detected_cls) != 0:
            st.success("Predicted Object : " + detected_cls[0])
            # st.text("Class index : " + str(query_class_index))
            pipeline_flag = True

        else:
            st.error("Can not predict object class")
            st.error("No need to run pipeline")

    
    # if pipeline_flag = True -> enable runpipeline button, else disable it
    # if pipeline_flag == True:
    if st.button("Run Pipeline"): 
        with st.spinner("Processing video..."):
            # Run your pipeline
            output_video = pipeline(tmp_img_path, tmp_vid_path, real_video_name)
            if output_video != None:
                st.text("Output video name : " + output_video)
            else:
                st.error("Not found target object in video")
                found_in_video = False 
                    
                # Wait a moment to ensure file is fully written
                time.sleep(1)
            
        if found_in_video == True:
            # Verify the file exists and has content
            if os.path.exists(output_video):
                file_size = os.path.getsize(output_video)
                st.success(f"✅ Video processed successfully! File size: {file_size / (1024*1024):.2f} MB")
                    
                # Read video file 
                with open(output_video, "rb") as f: 
                    video_bytes = f.read() 

                file_name = output_video.split(".")[0]
            
                # Download button 
                st.download_button( 
                    label="Download Output Video", 
                    data=video_bytes, 
                    file_name=f"{file_name}.mp4", 
                    mime="video/mp4" 
                ) 
            else:
                st.error(f"❌ Output video not found at: {output_video}")
                st.info("Check if the pipeline is creating the file in the correct location.")
 
else: 
    st.info("Please upload both an image and a video file.")